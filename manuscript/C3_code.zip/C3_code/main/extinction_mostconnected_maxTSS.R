# 2022.02.09
# We simulated primary extinction by removing most connected species in food web predicted by the ADBM which had the maximum TSS

library(R.utils)
library(NetworkExtinction)
library(network)
library(readxl)
library(dplyr)
library(ggplot2)

sourceDirectory("../C1_method/R", modifiedOnly=FALSE)
sourceDirectory("R", modifiedOnly=FALSE)

# For removing most connected nodes
dd_mc <- data.frame(n_ext = double(),
                    acc_sec_ext = integer(),
                    type = character(),
                    fw_name = character(),
                    S = integer(),
                    L = integer())

# Getting the foodweb name and tolerance
metadata_fw_tol <- read_excel("~/Google Drive/GitHub/C1_method_v2/data/parameter_values.xlsx")
n_fw <- length(metadata_fw_tol$foodweb)
fw_ind <- 1:n_fw

for(i in fw_ind){
  fw_name <- metadata_fw_tol$foodweb[i]
  fw_tol <- metadata_fw_tol$dist_rej[i]
  
  ADBM_ABC_fw_calc <- ADBM_ABC_fw_maxTSS(fw_name = fw_name, fw_tol = fw_tol)
  
  real_pred_mat <- ADBM_ABC_fw_calc$real_pred_mat
  if(is.null(rownames(real_pred_mat))){
    n_nodes <- dim(real_pred_mat)[1]
    rownames(real_pred_mat) <- as.character(1:n_nodes)
    colnames(real_pred_mat) <- as.character(1:n_nodes)
  }
  ADBM_ABC_pred_mat <- ADBM_ABC_fw_calc$ADBM_pred_mat
  
  S <- dim(real_pred_mat)[1]
  L_real <- sum(real_pred_mat)
  L_ADBM_ABC <- sum(ADBM_ABC_pred_mat)
  
  
  real_conn <- sum(real_pred_mat)/(dim(real_pred_mat)[1]^2)
  ADBM_ABC_conn <- sum(ADBM_ABC_pred_mat)/(dim(ADBM_ABC_pred_mat)[1]^2)
  
  real_ext_mc <- most_connected_ext(net = real_pred_mat)
  ADBM_ABC_ext_mc <- most_connected_ext(net = ADBM_ABC_pred_mat)
  
  dd_mc <- rbind(data.frame(n_ext = real_ext_mc$acc_pri_ext,
                            acc_sec_ext = real_ext_mc$acc_sec_ext,
                            type = "Empirical",
                            fw_name = fw_name,
                            S = S,
                            L = L_real),
                 data.frame(n_ext = ADBM_ABC_ext_mc$acc_pri_ext,
                            acc_sec_ext = ADBM_ABC_ext_mc$acc_sec_ext,
                            type = "ADBM",
                            fw_name = fw_name,
                            S = S,
                            L = L_ADBM_ABC),
                 dd_mc)
  print(fw_name)
}

# saveRDS(object = dd_mc, file = "results/most_connected_maxTSS.RDS")



