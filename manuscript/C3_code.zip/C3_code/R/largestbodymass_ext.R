# 2022.08.02
# Simulating extinction of species with largest body mass

largestbodymass_ext <- function(net, bodysize){
  
  dd <- data.frame(node = character(), acc_pri_ext = integer(), n_sec_ext = integer(), acc_sec_ext = integer())
  
  basal_species <- basal_species_fun(net)
  
  ## Removing isolated nodes
  isolated_nodes <- isolated_nodes_fun(net = net)
  not_isolated_nodes <- setdiff(x = colnames(net), y = isolated_nodes)
  net <- net[not_isolated_nodes, not_isolated_nodes]
  bodysize <- bodysize[not_isolated_nodes]
  
  new_net <- net
  k <- 1
  ext_list <- list()
  
  # Stop when all the species is extinct
  while(all(is.na(new_net)) == FALSE){

    node <- names(which.max(bodysize))
    
    ext_list[[k]] <- sim_single_ext_v2(net = new_net, node = node, basal_species = basal_species)
    new_net <- ext_list[[k]]$net
    bodysize <- bodysize[rownames(new_net)]
    
    if(k != 1){
      dd <- rbind(dd, 
                  data.frame(node = node, acc_pri_ext = k, n_sec_ext = ext_list[[k]][[2]],
                             acc_sec_ext = ext_list[[k]][[2]] + dd$acc_sec_ext[k-1])
      )
    }else{
      dd <- rbind(dd, 
                  data.frame(node = node, acc_pri_ext = k, n_sec_ext = ext_list[[k]][[2]],
                             acc_sec_ext = ext_list[[k]][[2]])
      )
    }
    
    k <- k + 1
    # print(k)
    
  }
  
  return(dd)
  
  
  
}